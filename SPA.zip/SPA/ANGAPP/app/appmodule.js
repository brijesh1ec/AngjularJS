﻿/// <reference path="../scripts/angular.min.js" />



(function () {
    'use strict';

    angular.module('app', []);

})()