﻿
/// <reference path="../scripts/angular.min.js" />
/// <reference path="../scripts/angular-route.min.js" />
/// <reference path="app.js" />



(function () {
    'use strict';

    angular.module('appInit.homecontrollers').controller('homecontroller', ['$scope', '$http', '$location', '$window', homecontroller]);

    function homecontroller($scope, $http, $location, $window) {
        var home = this;
        home.Title = "OMS";
    }

})();