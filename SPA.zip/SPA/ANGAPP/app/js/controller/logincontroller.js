﻿
/// <reference path="../scripts/angular.min.js" />
/// <reference path="../scripts/angular-route.min.js" />
/// <reference path="app.js" />




(function () {
    'use strict';

    angular.module('appInit').controller('logincontroller', ['$scope', '$http', '$location', '$window', logincontroller]);

    function logincontroller($scope, $http, $location, $window) {
        var vm = this;
        vm.login = loginservice;

        function loginservice() {

            //alert('hi');
            $window.location.href = "/app/views/home.html";

        }
    }

})();