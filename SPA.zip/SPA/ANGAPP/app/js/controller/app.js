﻿/// <reference path="../scripts/angular.min.js" />
/// <reference path="../scripts/angular-route.min.js" />
/// <reference path="script.js" />

/////http://www.codeproject.com/Articles/813421/AngularJS-On-demand-loading
////http://stackoverflow.com/questions/15939913/single-page-application-load-js-file-dynamically-based-on-partial-view

////http://benohead.com/angularjs-requirejs-dynamic-loading-and-pluggable-views/
////http://stackoverflow.com/questions/20909525/load-controller-dynamically-based-on-route-group

////http://stackoverflow.com/questions/12197880/angularjs-how-to-make-angular-load-script-inside-ng-include
////http://stackoverflow.com/questions/11003916/angularjs-how-do-i-switch-views-from-a-controller-function

////http://ify.io/unit-testing-lazily-loaded-angularjs-artefacts/


////http://codereview.stackexchange.com/questions/68251/dynamically-load-assets-cssimagescontrollers-on-route-resolve


var app;

(function () {

    'use strict';

    angular.module('appInit.leadcontrollers', []);
    angular.module('appInit.homecontrollers', []);

    angular.module('appInit', ['ngRoute', 'appInit.leadcontrollers', 'appInit.homecontrollers']);

    angular.module('appInit').config(['$routeProvider', '$controllerProvider',
  function ($routeProvider, $controllerProvider) {
      //angular.module('appInit').controller = $controllerProvider.register;
      $routeProvider
      .when('/lead', {
          templateUrl: '/app/views/lead.html', controller: 'leadcontroller', controllerAs: 'lead'
      })
      .when('/customer', { templateUrl: '/app/views/lead.html', controller: 'customercontroller', controllerAs: 'customer' })
      .when('/home', { templateUrl: '/app/views/home.html', controller: 'homecontroller', controllerAs: 'home' });
      //.otherwise(redirectTo'/home');





  }]);



})();