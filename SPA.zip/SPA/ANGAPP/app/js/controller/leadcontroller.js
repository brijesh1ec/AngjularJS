﻿
/// <reference path="../scripts/angular.min.js" />
/// <reference path="../scripts/angular-route.min.js" />
/// <reference path="app.js" />



(function () {
    'use strict';

    angular.module('appInit.leadcontrollers').controller('leadcontroller', ['$scope', '$http', '$location', '$window', leadcontroller]);

    function leadcontroller($scope, $http, $location, $window) {
        alert('hi');
        var lead = this;
        lead.Title = "Lead";
    }
})();